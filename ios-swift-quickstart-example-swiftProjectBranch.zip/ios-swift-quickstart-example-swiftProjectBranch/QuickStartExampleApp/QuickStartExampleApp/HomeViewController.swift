//
//  HomeViewController.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 02/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit
import Parse
import Foundation

class HomeViewController: UIViewController {

    var promo = [PFObject]()
    var itemSelected = Int()
    @IBOutlet weak var promoTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.promoTableView.delegate = self
        self.promoTableView.dataSource = self
        // Do any additional setup after loading the view.
        initController()
 
        if let currentUser = PFUser.current() {
            print(currentUser)
            PFUser.current()?.fetchInBackground(block: { (user, error) in
                if let cust = user?.object(forKey: "customerId") as? String {
                    print(cust)
                } else {
                    //CAMBIAR AQUI
                    // self.retriveCustomerId()
                }
            })
        }
        
        
    }

    
    @IBAction func openNav(_ sender: Any) {
        performSegue(withIdentifier: "navSegue", sender: self)
    }
    @IBAction func addbut(_ sender: Any) {
        performSegue(withIdentifier: "addSegue", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    private func initController() {
        if isConnectedToNetwork() {
            loadCategories()
        } else {
            let alert = UIAlertController(title: "RESERVERP", message: "No hay acceso a internet", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    
    func loadCategories() {

        let query = PFQuery(className: "Promos")
        //query.order(byAscending: "order")
        query.findObjectsInBackground {
            (objects: [PFObject]?, error: Error?) -> Void in
           
            
            if let error = error {
                
                // Handle error
                NSLog(error.localizedDescription)
                self.showAlert(withMessage: error.localizedDescription)
                
            } else {
                print("exito")
                // Handle success
                self.promo.removeAll()
                for object in objects! {
                    self.promo.append(object)
                }
                self.promoTableView.reloadData()
                DispatchQueue.main.async{
                    self.promoTableView.reloadData()
                }
                print("promo", self.promo)
                print("count", self.promo.count)
//                if let title = self.promo[0].object(forKey: "day") as? String {
//                   print("titulo: ",title)
//
//                }
                
            }
        }
    
    }
    
   
    
    
    
    
}


extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.promo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "promoCell") as! PromoCell

        if let day = self.promo[indexPath.row].object(forKey: "day") as? String {
            cell.title.text = day
        }
        if let desc = self.promo[indexPath.row].object(forKey: "description") as? String {
            cell.desc.text = desc
        }
        
        if let categoryImg = self.promo[indexPath.row].object(forKey: "image") as? PFFile {
            categoryImg.getDataInBackground { (data, error) -> Void in
                if let downloadedImage = UIImage(data: data!) {
                    cell.imag.image = downloadedImage
                }
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.itemSelected = indexPath.row
        
        if let desc = self.promo[indexPath.row].object(forKey: "modal") as? String {
            let alert = UIAlertController(title: "RESERVERP", message: desc, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
        }

       
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.preservesSuperviewLayoutMargins = false
    }
}



