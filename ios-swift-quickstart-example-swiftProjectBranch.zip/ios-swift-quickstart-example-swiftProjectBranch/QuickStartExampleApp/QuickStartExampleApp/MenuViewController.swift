//
//  MenuViewController.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 03/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit
import Parse
import Foundation

class MenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}
