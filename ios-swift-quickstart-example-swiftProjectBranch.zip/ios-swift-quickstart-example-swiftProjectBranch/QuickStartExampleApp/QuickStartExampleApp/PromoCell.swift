//
//  promoCellTableViewCell.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 02/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit

class PromoCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var imag: UIImageView!

}
