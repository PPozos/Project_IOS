//
//  UsuariosViewController.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 03/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit
import Parse
import Foundation

class UsuariosViewController: UIViewController {

    var usuario = [PFObject]()
    var itemSelected = Int()
    @IBOutlet weak var usuariosTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.usuariosTableView.delegate = self
        self.usuariosTableView.dataSource = self
        loadUsers()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func loadUsers() {
        
        let query = PFQuery(className: "Usuario")
        //query.order(byAscending: "order")
        query.findObjectsInBackground {
            (objects: [PFObject]?, error: Error?) -> Void in
            
            
            if let error = error {
                
                // Handle error
                NSLog(error.localizedDescription)
                self.showAlert(withMessage: error.localizedDescription)
                
            } else {
                // Handle success
                self.usuario.removeAll()
                for object in objects! {
 
                    self.usuario.append(object)
                }
                self.usuariosTableView.reloadData()
                print ("usuario: ", self.usuario)

                
            }
        }
        
    }

    

}


extension UsuariosViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.usuario.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "usuarioCell") as! usuarioCell
        
        if let nombre = self.usuario[indexPath.row].object(forKey: "nombre") as? String {
            cell.titulo.text = nombre
        }
        if let rol = self.usuario[indexPath.row].object(forKey: "role") as? Int {
            if rol ==  0 {
                cell.rol.text = "ADMIN"
            }
            if rol == 1 {
            cell.rol.text = "RP"
        }
        }
        if let categoryImg = self.usuario[indexPath.row].object(forKey: "image") as? PFFile {
            categoryImg.getDataInBackground { (data, error) -> Void in
                if let downloadedImage = UIImage(data: data!) {
                    cell.img.image = downloadedImage
                }
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.itemSelected = indexPath.row
        self.performSegue(withIdentifier: "editarAbrir", sender: self)
        
        
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.preservesSuperviewLayoutMargins = false
    }



}
