
import Foundation
import UIKit
import SystemConfiguration
import Parse

class Utils: UIViewController {
    
    class func isUserAuthenticated() -> Bool {
        return PFUser.current() != nil;
    }
    
    class func resizeImage(image: UIImage) -> UIImage {
        let targetSize = CGSize(width: 350.0, height: 350.0)
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
}

extension UIViewController {
 
    func createAlert(view_controller: UIViewController, title: String, message: String) {
        let alertC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "Aceptar", style: .default) { (action) in
        }
        alertC.addAction(OKAction)
        view_controller.present(alertC, animated: true, completion: nil)
    }
    
    /// Show a UIAlertController with the specified message
    func showAlert(withMessage message: String) {
        
        let alert = UIAlertController(
            title: "Oops...",
            message: message,
            preferredStyle: UIAlertControllerStyle.alert
        )
        
        let action = UIAlertAction(
            title: "Ok",
            style: UIAlertActionStyle.default,
            handler: nil
        )
        
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
        
    }
    

    
    func makeNavigationBarInvisible() {
        let navBar = self.navigationController?.navigationBar
        if navBar != nil {
            navBar!.setBackgroundImage(UIImage(), for: .default)
            navBar!.shadowImage = UIImage()
            navBar!.isTranslucent = true
        }
    }
    
    func makeNavigationBarVisible() {
        let navBar = self.navigationController?.navigationBar
        if navBar != nil {
            navBar!.setBackgroundImage(nil, for: .default)
            navBar!.shadowImage = UIImage()
            navBar!.isTranslucent = true
        }
    }
    
    func imageInNavBar() {
        let image = UIImage(named: "logonav.jpg")
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        imageView.image = image
        imageView.contentMode = .scaleAspectFit
        navigationItem.titleView = imageView
    }
    
    /// Instance of Main Storyboard
    func getStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    
    func statusOrder(status: String) -> String {
        
        var statusSpanish = ""
        if status == "pending" {
            statusSpanish = "Pendiente"
        }
        
        if status == "accepted" {
            statusSpanish = "Aceptado"
        }
        
        if status == "rejected" {
            statusSpanish = "Rechazado"
        }
        
        if status == "delivered" {
            statusSpanish = "Entregado"
        }
        return statusSpanish
    }
    
    func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        
        return ret
        
    }
    
    func handleNSError(_ error: NSError) {
        NSLog("\(error.code): \(error.localizedDescription)")
        self.showAlert(withMessage: error.localizedDescription)
    }
    
    func handleError(_ error: Error) {
        NSLog(error.localizedDescription)
        self.showAlert(withMessage: error.localizedDescription)
    }
    
    func handleErrorDescription(_ error: NSError) {
        NSLog(error.description)
        self.showAlert(withMessage: error.localizedDescription)
    }
    
    func showToast(message: String) {
        
        let w = UIScreen.main.bounds.width
        let h = UIScreen.main.bounds.height
        
        let toastLabel = UILabel(frame: CGRect(x: w / 2, y: h, width: 220, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Helvetica", size: 12.0)
        toastLabel.text = message
        toastLabel.center = CGPoint(x: w / 2, y: h - 130)
        toastLabel.alpha = 0.0
        toastLabel.numberOfLines = 0
        toastLabel.layer.cornerRadius = 35 / 2;
        toastLabel.clipsToBounds = true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 0.6, animations: {
            toastLabel.alpha = 1.0
        }, completion: { (isCompleted) in
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.6) {
                UIView.animate(withDuration: 0.6, animations: {
                    toastLabel.alpha = 0.0
                }, completion: { (isCompleted) in
                    toastLabel.removeFromSuperview()
                })
            }
        })
    }
}

extension UIColor {
    class func primaryColor() -> UIColor {
        return UIColor(red: 0.80, green: 0.84, blue: 0.80, alpha: 1.0)
    }
    
    class func secondaryColor() -> UIColor {
        return UIColor.black
    }
    
    class func buttonColor() -> UIColor {
        return UIColor(red: 0.55, green: 0.72, blue: 1.0, alpha: 1.0)
    }
    
    var toHexString: String {
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        
        self.getRed(&r, green: &g, blue: &b, alpha: &a)
        
        return String(
            format: "%02X%02X%02X",
            Int(r * 0xff),
            Int(g * 0xff),
            Int(b * 0xff)
        )
    }
}

extension CGRect {
    
    init(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) {
        
        self.init(x: x, y: y, width: w, height: h)
    }
}

extension Double {
    func truncate(places: Int) -> Double {
        return Double(floor(pow(10.0, Double(places)) * self) / pow(10.0, Double(places)))
    }
}

extension UITextField {
    func setPadding(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

