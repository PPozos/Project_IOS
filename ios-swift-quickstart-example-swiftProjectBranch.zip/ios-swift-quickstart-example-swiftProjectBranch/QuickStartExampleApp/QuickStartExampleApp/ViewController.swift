//
//  ViewController.swift
//  QuickStartExampleApp
//
//  Created by Joren Winge on 11/8/17.
//  Copyright © 2017 Back4App. All rights reserved.
//

import UIKit
import Parse
import Foundation

class ViewController: UIViewController {
    var loginv = false
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
//        var myFirstClass = PFObject(className:"MyFirstClass")
//        myFirstClass["name"] = "I'm able to save objects!"
//        myFirstClass.saveInBackground {
//            (success: Bool, error: Error?) in
//            if (success) {
//                // The object has been saved.
//            } else {
//                // There was a problem, check error.description
//            }
//        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func LogIn(_ sender: Any) {
        validateFields()

        if loginv == true {
                performSegue(withIdentifier: "InicioSegue", sender:self)
            
        }

    }
    
    func isValidEmail(testStr: String) -> Bool {
        //let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        let emailRegEx = "^\\w+([\\.\\+\\-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,4})+$"
        
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    func login() {
        

        PFUser.logInWithUsername(inBackground: self.emailField.text!.lowercased(), password: self.passwordField.text!) {
            (user: PFObject?, error: Error?) -> Void in
            
            if let e = error {
                
                // Handle error
                NSLog(e.localizedDescription)
                
                let alert = UIAlertController(title: "RESERVERP", message: "Correo o contrasena invalida", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(alert, animated: true, completion: nil)
                
            } else {
                
                let currentInstallation = PFInstallation.current()
                currentInstallation!.addUniqueObject("user_" + user!.objectId!, forKey: "channels")
                currentInstallation!.saveInBackground()
                self.loginv = true
                
             
                
            }
            
        }
    }
    
    
    
    func validateFields() {
        if emailField.text?.lowercased() == "" {
            let alert = UIAlertController(title: "RESERVERP", message: "Necesitas ingresar una cuenta de correo valida", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        if !isValidEmail(testStr: emailField.text!) {
            let alert = UIAlertController(title: "RESERVERP", message: "Necesitas ingresar una cuenta de correo valida", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        if passwordField.text == "" {
            let alert = UIAlertController(title: "RESERVERP", message: "Necesitas ingresar una contrasena", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        login()
    }
    
}

