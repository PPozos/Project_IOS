//
//  addPromoViewController.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 03/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit
import Parse

class addPromoViewController: UIViewController {

    @IBOutlet weak var dayField: UITextField!
    @IBOutlet weak var tituloField: UITextView!
    @IBOutlet weak var descriptionField: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func cancel(_ sender: Any) {
        performSegue(withIdentifier: "addClose", sender: self)
    }
    
    @IBAction func agregarPromocion(_ sender: Any) {
        let promo = PFObject(className:"Promos")
        promo["day"] = dayField.text
        promo["description"] = tituloField.text
        promo["modal"] = descriptionField.text
        promo.saveInBackground { (succeeded, error)  in
            if (succeeded) {
                let alert = UIAlertController(title: "RESERVERP", message: "Se ha guardado la promoción de manera exitosa.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(alert, animated: true, completion: nil)
            } else {
                let alert = UIAlertController(title: "RESERVERP", message: "No se ha podido crear la promo.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    

}
