//
//  usuarioCell.swift
//  QuickStartExampleApp
//
//  Created by Pablo Pozos Aguilar on 03/12/19.
//  Copyright © 2019 Back4App. All rights reserved.
//

import UIKit

class usuarioCell: UITableViewCell {

    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var rol: UILabel!
    @IBOutlet weak var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
